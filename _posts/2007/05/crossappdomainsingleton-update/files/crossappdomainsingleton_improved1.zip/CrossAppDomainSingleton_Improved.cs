using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace DoLittle.Framework
{
	public class CrossAppDomainSingleton<T> : MarshalByRefObject where T:new()
	{
		#region Private Fields
		// Name of the singleton appdomain
		private static readonly string AppDomainName = "Singleton AppDomain";

		// The private instance of the singleton
		private static T _instance;

		// Sync object for thread safety - we lock on this when we need to access
		// the _instance field of this singleton
		private static readonly object _syncLock = new object();
		#endregion

		#region Private Methods

		/// <summary>
		/// 
		/// </summary>
		/// <param name="friendlyName"></param>
		/// <returns></returns>
		private static AppDomain GetAppDomain(string friendlyName)
		{
			IntPtr enumHandle = IntPtr.Zero;
			mscoree.CorRuntimeHostClass host = new mscoree.CorRuntimeHostClass();
			try
			{
				host.EnumDomains(out enumHandle);

				object domain = null;
				while (true)
				{
					host.NextDomain(enumHandle, out domain);
					if (domain == null) 
					{
						break;
					}
					AppDomain appDomain = (AppDomain)domain;
					if( appDomain.FriendlyName.Equals(friendlyName) ) 
					{
						return appDomain;
					}
				}
			}
			finally
			{
				host.CloseEnum(enumHandle);
				Marshal.ReleaseComObject(host);
				host = null;
			}
			return null;
		}

		#endregion

		#region Public Methods
		/// <summary>
		/// Override of lifetime service initialization.
		/// 
		/// The reason for overriding is to have this singleton live forever
		/// </summary>
		/// <returns>object for the lease period - in our case always null</returns>
		public override object InitializeLifetimeService()
		{
			// We want this singleton to live forever
			// In order to have the lease across appdomains live forever,
			// we return null.
			// To read more : http://msdn.microsoft.com/msdnmag/issues/03/12/LeaseManager/default.aspx
			return null;
		}
		#endregion

		#region Public Properties
		/// <summary>
		/// The singleton Instance of the object
		/// </summary>
		public static T Instance
		{
			get
			{
				lock (_syncLock)
				{
					if (null == _instance)
					{
						AppDomain appDomain = GetAppDomain(AppDomainName);
						if (null == appDomain)
						{
							appDomain = AppDomain.CreateDomain(AppDomainName);

							// We want the AppDomain to live forever
							appDomain.InitializeLifetimeService();
						}
						Type type = typeof(T);
						_instance = (T)appDomain.CreateInstanceAndUnwrap(type.Assembly.FullName, type.FullName);
					}

					return _instance;
				}

			}
		}
		#endregion
	}


	public class MySingleton : CrossAppDomainSingleton<MySingleton>
	{

		public void HelloWorld()
		{
			Console.WriteLine("Hello world from '" + AppDomain.CurrentDomain.FriendlyName + " (" + AppDomain.CurrentDomain.Id + ")'");
		}
	}

	public class TestClass : MarshalByRefObject
	{
		public void TestMethod()
		{
			Console.WriteLine("**** Test method running in '" + AppDomain.CurrentDomain.FriendlyName + " (" + AppDomain.CurrentDomain.Id + ")' ****");
			MySingleton.Instance.HelloWorld();
			Console.WriteLine("\n\n");
		}
	}

	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("**** Call HelloWorld in root appdomain '" + AppDomain.CurrentDomain.FriendlyName + " (" + AppDomain.CurrentDomain.Id + ")' ****");
			MySingleton.Instance.HelloWorld();

			Console.WriteLine("\n\n");

			AppDomain dataDomain = AppDomain.CreateDomain("Data Domain");
			AppDomain logicDomain = AppDomain.CreateDomain("Business Logic Domain");


			Type testClassType = typeof(TestClass);
			TestClass dataDomainTestClass = (TestClass)dataDomain.CreateInstanceAndUnwrap(testClassType.Assembly.FullName,testClassType.FullName);
			TestClass logicDomainTestClass = (TestClass)logicDomain.CreateInstanceAndUnwrap(testClassType.Assembly.FullName, testClassType.FullName);


			dataDomainTestClass.TestMethod();
			logicDomainTestClass.TestMethod();
		}
	}
}
